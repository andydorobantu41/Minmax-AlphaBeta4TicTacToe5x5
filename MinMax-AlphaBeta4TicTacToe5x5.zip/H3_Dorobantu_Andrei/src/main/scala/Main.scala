import scala.io.StdIn
import scala.util.Properties.userName

object Main {
  // A 5x5 Tic-Tac-Toe: (or 3x3)
  type Line = List[Player]
  type Board = List[Line]

  def profileID: Int = 1

  def newline = "\n"

  // HW 3 - Task 1:
  // Creates a board from a string
  def makeBoard(s: String): Board = {
    def toPos(c: Char): Player =
      c match {
        //first player
        case 'X' => One
        //second player
        case '0' => Two
        //empty space
        case _ => Empty
      }

    s.split('\n')
      .map(_.map(c => toPos(c)).toList)
      .toList
  }

  // HW 3 - Task 2:
  // Checks if the position (x,y) board b is free
  def isFree(x: Int, y: Int, b: Board): Boolean = {
    b(x)(y) match {
      case One => false
      case Two => false
      case Empty => true
    }
  }

  // HW 3 - Task 3:
  // Returns the "other" player from a position, if it exists
  def complement(p: Player): Player = {
    p match {
      case One => Two
      case Two => One
      case _ => Empty
    }
  }

  // HW 3 - Task 1:
  // Shows the board as a string (somewhat reverse method of makeBoard)
  def show(b: Board): String = {
    def auxShow(p: Player): String = {
      p match {
        case One => "X"
        case Two => "0"
        case Empty => "."
      }
    }

    b.map(list => list.map(auxShow))
      .map(_.reduce(_ ++ _))
      .reduce(_ ++ "\n" ++ _)
  }

  // HW 3 - Task 5:
  // Return the columns of the board by showing the lines/rows of the flipped-to-the-left board
  def getColumns(b: Board): Board = {
    var flippedBoardString = ""
    for (line <- 0 until b.length) {
      for (column <- 0 until b(line).length) {
        //do a reverse of the string (column)(line) instead of (line)(column)
        val player = b(column)(line) match {
          case One => 'X'
          case Two => '0'
          case Empty => '.'
        }
        flippedBoardString += player
      }
      flippedBoardString += "\n"
    }
    makeBoard(flippedBoardString)
  }

  // HW 3 - Task 6:
  // Get the elements of the first and second diagonal and put them in a line
  def getFstDiag(b: Board): Line = {
    (for (i <- 0 until b.length)
      yield b(i)(i)).toList
  }

  def getSndDiag(b: Board): Line = {
    (for (i <- 0 until b.length)
      yield b(b.length - 1 - i)(i)).toList
  }

  // HW 3 - Task 7:
  // Implement a list of lines, containg what is above and below each of the diagonals
  def getAboveFstDiag(b: Board): List[Line] = {
    def auxAbove(b: Board): Board = {
      (for (line <- 0 until b.length)
        yield (for (column <- (line + 1) until b.length)
          yield b(line)(column)).toList).toList
    }

    getColumns(auxAbove(b))
  }

  def getBelowFstDiag(b: Board): List[Line] =
    getAboveFstDiag(getColumns(b))

  def getAboveSndDiag(b: Board): List[Line] =
    getAboveFstDiag(b.map(_.reverse))

  def getBelowSndDiag(b: Board): List[Line] =
    getBelowFstDiag(b.map(_.reverse))

  // HW 3 - Task 8:
  // Come up with a win condition check for current player
  def winner(p: Player)(b: Board): Boolean = {
    // winner on one of the lines:
    b.exists(line => {
      line.count(elem => (elem == p)) >= 5
    }) ||
      // winner on one of the columns:
      getColumns(b).exists(column => {
        column.count(elem => (elem == p)) >= 5
      }) ||
      // winner on the 1st diagonal:
      (getFstDiag(b).count(elem => (elem == p)) >= 5) ||
      // winner on the 2nd diagonal:
      (getSndDiag(b).count(elem => (elem == p)) >= 5) ||
      // winners above and below the first and the second
      getAboveFstDiag(b).exists(line => {
        line.count(elem => (elem == p)) >= 5
      }) ||
      getBelowFstDiag(b).exists(line => {
        line.count(elem => (elem == p)) >= 5
      }) ||
      getBelowSndDiag(b).exists(line => {
        line.count(elem => (elem == p)) >= 5
      }) ||
      getAboveSndDiag(b).exists(line => {
        line.count(elem => (elem == p)) >= 5
      })
  }

  // HW 3 - Task 9:
  // Insert the move of a player in a board and return the new board
  def update(p: Player)(ln: Int, col: Int, b: Board): Board = {
    (for (line <- 0 until b.length)
      yield (for (column <- 0 until b(line).length)
        yield {
          if (line == ln && column == col) p
          else b(line)(column)
        }).toList).toList
  }

  // HW 3 - Task 10:
  // Make a list of all possible moves, where the current player can play, given the current board
  def next(p: Player)(b: Board): List[Board] = {
    if (winner(p)(b)) List(b)
    else
      (for (line <- 0 until b.length;
            column <- 0 until b.length
            if isFree(line, column, b))
      yield update(p)(line, column, b)).toList
  }

  // HW 4B - Task B1:
  // Quantifying the potential of a board:
  // Sequence1: The hardcoded mess:
  def sequences(p: Player)(b: Board): Map[Int, Int] = {
    // Get tuple for the first diagonal
    val fstDiag = (getFstDiag(b).count(_ == p), getFstDiag(b).count(_ == complement(p)))

    // Get tuple for the second diagonal
    val sndDiag = (getSndDiag(b).count(_ == p), getSndDiag(b).count(_ == complement(p)))

    // Get a list of tuples for above the first diagonal
    val aboveFstDiag =
      getAboveFstDiag(b)
        .filter(lst => lst.length >= 5)
        .map(line => (line.count(_ == p), line.count(_ == complement(p))))

    // Get a list of tuples for below the first diagonal
    val belowFstDiag =
      getBelowFstDiag(b)
        .filter(lst => lst.length >= 5)
        .map(line => (line.count(_ == p), line.count(_ == complement(p))))

    // Get a list of tuples for above the second diagonal
    val aboveSndDiag =
      getAboveSndDiag(b)
        .filter(lst => lst.length >= 5)
        .map(line => (line.count(_ == p), line.count(_ == complement(p))))

    // Get a list of tuples for below the second diagonal
    val belowSndDiag =
      getBelowSndDiag(b)
        .filter(lst => lst.length == 5)
        .map(line => (line.count(_ == p), line.count(_ == complement(p))))

    // Get a list of tuples for all the lines/rows
    val checkLines = b.map(line => (line.count(_ == p), line.count(_ == complement(p))))

    // Get a list of tuples for all the columns
    val checkColumns = getColumns(b).map(line => (line.count(_ == p), line.count(_ == complement(p))))

    // Merge all of them into one list of all possible tuples
    val allPossibilities = List(fstDiag) ++ List(sndDiag) ++ aboveSndDiag ++ belowSndDiag ++ aboveFstDiag ++ belowFstDiag ++ checkLines ++ checkColumns
    //println(allPossibilities)

    // Filter and pick only the favorable ones (current player has where to win)
    val filteredPossibilities = allPossibilities.filter { case (_, y) => y <= b.length - 5 }
    //println(filteredPossibilities)

    def countSequences(l: List[(Int, Int)], noOfOccurences: Int): Int = {
      l.count(_._1 == noOfOccurences)
    }

    Map(
      (5, countSequences(filteredPossibilities, 5)),
      (4, countSequences(filteredPossibilities, 4)),
      (3, countSequences(filteredPossibilities, 3)),
      (2, countSequences(filteredPossibilities, 2)),
      (1, countSequences(filteredPossibilities, 1))
    )

  }

  // AI
  // HW 4B - Task B1:
  // 1. Making a method, which returns a list of all available positions
  def availablePositions(b: Board): List[(Int, Int)] = {
    var listOfPositions: List[(Int, Int)] = Nil
    for (line <- b.indices) {
      for (column <- b(0).indices) {
        if (b(line)(column) == Empty) listOfPositions = listOfPositions ::: ((line, column) :: Nil)
      }
    }
    listOfPositions
  }

  // HW 4B - Task B2:
  def minMaxAndAlfaBeta(p: Player)(b: Board): (Int, Int) = {
    // minMax with alfa-beta pruning
    def minimax(board: Board, level: Int, isMax: Boolean, a: Int, b: Int): Int = {
      // Declare Alpha Beta for pruning:
      var alpha = a
      var beta = b
      // Get list of positions, to test out
      val available = availablePositions(board)
      val scoreOfAI = sequences(p)(board)
      val scoreOfHuman = sequences(complement(p))(board)
      // Checking it AI has better odds than the human
      if (scoreOfAI(5) > 0 || scoreOfAI(4) > 0 || scoreOfAI(3) > 0 || scoreOfAI(2) > 0 || scoreOfAI(1) > 0) {
        (math.max(scoreOfAI(5) * 1000, math.max(scoreOfAI(4) * 100, math.max(scoreOfAI(3) * 10, scoreOfAI(2))))
          - math.max(scoreOfHuman(5) * 1000, math.max(scoreOfHuman(4) * 100, math.max(scoreOfHuman(3) * 10, scoreOfHuman(2)))))
      }
        // Checking if the Human has better odds than the AI
      else {
        if (scoreOfHuman(5) > 0 || scoreOfHuman(4) > 0 || scoreOfHuman(3) > 0 || scoreOfHuman(2) > 0) {
          -math.max(scoreOfHuman(5) * 1000, math.max(scoreOfHuman(4) * 100, math.max(scoreOfHuman(3) * 10, scoreOfHuman(2))))
        }
        if (available.isEmpty) {
          return 0
        }
        // Maximizing the AI:
        if (isMax) {
          var bestScore = Int.MinValue
          for ((x, y) <- available) {
            val updatedBoard = update(p)(x, y, board)
            val scores = minimax(updatedBoard, level + 1, !isMax, alpha, beta)
            bestScore = math.max(bestScore, scores)
            if (bestScore >= beta) return bestScore
            alpha = math.max(alpha, bestScore)
          }
          bestScore
        }
        // Minimizing the human:
        else {
          var bestScore = Int.MaxValue
          for ((x, y) <- available) {
            val updatedBoard = update(complement(p))(x, y, board)
            val score = minimax(updatedBoard, level + 1, isMax, alpha, beta)
            bestScore = math.min(bestScore, score)
            if (bestScore <= alpha) return bestScore
            beta = math.min(beta, bestScore)
          }
          bestScore
        }
      }
    }

    // Returns the best move for the player p using the minimax algorithm
    def findBestMove(board: Board, p: Player): (Int, Int) = {
      println("Entered findBestMove:")
      var bestMove = (-1, -1)
      var bestScore = -10000
      val available = availablePositions(board)
      for ((x, y) <- available) {
        val updatedBoard = update(p)(x, y, board)
        val score = minimax(updatedBoard, 0, true, a = Int.MinValue, b = Int.MaxValue)
        if (score > bestScore) {
          bestScore = score
          bestMove = (x, y)
        }
      }
      bestMove
    }

    findBestMove(b, p)
  }

  def isFull(b: Board): Boolean = {
    b.forall(line => line.forall(player => player != Empty))
  }

  var emptyBoard5x5 = makeBoard(".....\n.....\n.....\n.....\n.....")

  //B.2:
  def play(p: Player, b: Board): Board = {
    // Print current board
    println(toString(b))

    // Get input from console from human
    print("Pick a place (Line & column - separated by space): ")
    val Array(x, y) = StdIn.readLine().split(" ").map(_.toInt)

    // Check if the console input is in or out of bounds
    if (x >= b.length || x < 0 || y >= b.length || y < 0) {
      println("Input is out of bounds...Choose again!")
      play(p, b)
    }
    // Make a move
    if (isFree(x, y, b)) {
      val updatedBoard = update(p)(x, y, b)
      println(toString(updatedBoard))
      // Human Player won:
      if (winner(p)(updatedBoard)) {
        println("Human won! End of the game! \n Printing results...\n" + toString(updatedBoard))
        updatedBoard
      }
      else if (!isFull(updatedBoard)) {
        // Keep playing, call minmax:
        // Play the AI
        println("AI is thinking...")
        // First move of the AI:
        // It takes A LOT of time for the first move, so the best strategy is to play a corner:
        if (b == emptyBoard5x5) {
          var FirstRoundBoard: Board = makeBoard(".....\n.....\n.....\n.....\n.....")
          (x + y) match {
            case 0 =>
              println("AI first move at " + 0 + ", " + 4)
              FirstRoundBoard = update(complement(p))(0, 4, updatedBoard)
            case 4 =>
              println("AI first move at " + 4 + ", " + 4)
              FirstRoundBoard = update(complement(p))(4, 4, updatedBoard)
            case _ =>
              println("AI first move at " + 0 + ", " + 0)
              FirstRoundBoard = update(complement(p))(0, 0, updatedBoard)
          }
          play(p, FirstRoundBoard)
        }
        // AI move (any other move than the first one)
        else {
          val (x, y) = minMaxAndAlfaBeta(complement(p))(updatedBoard)
          println(s"AI played at $x, $y")
          val newRoundBoard = update(complement(p))(x, y, updatedBoard)
          //AI Won
          if (winner(complement(p))(newRoundBoard)) {
            println("AI won! End of the game!\n Printing results...\n" + toString(newRoundBoard))
            newRoundBoard
          }
          // Human gets another turn
          else {
            play(p, newRoundBoard)
          }
        }

      }
      // Board is full, with no winners, game ended in draw
      else {
        println("Draw! End of the game!" + "\n" + toString(updatedBoard))
        updatedBoard
      }
    }
    // Move has a position that is already occupied
    else {
      println("The place is occupied...Choose again!")
      play(p, b)
    }
  }

  // Aesthetic TicTacToe Board:
  def toString(b: Board): String = {
    val dashes = "-" * (b.length * 3 + b.length - 1)
    b.map(line => line.map(player => s" $player "))
      .map(line => line.mkString("|"))
      .mkString(s"\n$dashes\n")
  }

  // Initializing the game:
  def main(args: Array[String]) = {
    println(s"Welcome to my TicTacToe, $userName!")
    play(Two, makeBoard(".....\n.....\n.....\n.....\n....."))
    //play(One, makeBoard("......\n......\n......\n......\n......\n......"))
    //play(One, makeBoard(".......\n.......\n.......\n.......\n.......\n.......\n......."))

    println("\n")

    // Testing Sequences function
    /*
    //SEQUENCES TEST FOR 7X7
    println(toString(makeBoard("""0000000
0000X00
000..X0
00.0...
..X.X0.
0X..0X.
X.0.0.0""")))
    println(sequences(Two)(makeBoard
    ("""0000000
0000X00
000..X0
00.0...
..X.X0.
0X..0X.
X.0.0.0""")))
    println("\n")

    //SEQUENCES TEST FOR 6x6
    println(toString(makeBoard("""0X0X0.
000.X0
0.0X..
0..0..
0X..0X
...X..""")))
    println(sequences(Two)(makeBoard
    ("""0X0X0.
000.X0
0.0X..
0..0..
0X..0X
...X..""")))
    println("\n")

    //SEQUENCES TEST FOR 5x5
    println(toString(makeBoard("""00000
0000X
000..
00.0.
0X..0""")))
    println(toString(makeBoard("""00000
0000X
000..
00.0.
0X..0""")))

    println(sequences(Two)(makeBoard
    ( """00000
0000X
000..
00.0.
0X..0""")))
    */


  }
}

